
function filter(data, plaintext) {
  var startswithcr = /^[^\n]*\r/.test(data);
}
