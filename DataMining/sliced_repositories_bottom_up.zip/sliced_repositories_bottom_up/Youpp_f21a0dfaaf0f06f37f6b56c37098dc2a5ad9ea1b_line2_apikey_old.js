module.exports = {
	key: "AIzaSyD88ejeWUIVWmU7j5lhZNLyP9q3S6TFtFQ"
};
