  async fetch({ specUrl }) {
    return this._requestJson({
      options: {
        qs: {
        },
      },
    })
  }
