var http = require("http");
var app = http.createServer(handler);
app.listen(39322);
