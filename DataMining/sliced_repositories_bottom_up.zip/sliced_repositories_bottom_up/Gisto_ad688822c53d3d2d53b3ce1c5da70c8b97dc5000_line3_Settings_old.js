const Settings = (props) => (
  <div>Settings</div>
);
