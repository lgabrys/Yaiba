app.controller('searchCtrl', function ($scope, $http, $stateParams) {
    $scope.title = 'Search results';
});
