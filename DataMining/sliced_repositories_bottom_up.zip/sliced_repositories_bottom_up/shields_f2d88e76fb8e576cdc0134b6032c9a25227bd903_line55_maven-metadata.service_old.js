
export default class MavenMetadata extends BaseXmlService {
  async fetch({ metadataUrl }) {
    return this._requestXml({
      schema,
      url: metadataUrl,
      parserOptions: { parseNodeValue: false },
    })
  }
}
