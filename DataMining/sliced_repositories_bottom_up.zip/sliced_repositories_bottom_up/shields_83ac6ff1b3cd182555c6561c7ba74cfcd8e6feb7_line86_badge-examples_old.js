import PropTypes from 'prop-types'
const Category = ({ category, examples, baseUrl, longCache, onClick }) => {
  return (
      <Link to={'/examples/' + category.id}>
  )
}
