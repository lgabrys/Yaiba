$(function(){
  var Jobs = new JobList();
});
