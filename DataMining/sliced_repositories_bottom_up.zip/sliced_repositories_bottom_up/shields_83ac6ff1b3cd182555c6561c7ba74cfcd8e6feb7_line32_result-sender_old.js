function streamFromString(str) {
}
function sendOther(format, res, askres, end) {
  askres.setHeader('Content-Type', 'image/' + format)
}
