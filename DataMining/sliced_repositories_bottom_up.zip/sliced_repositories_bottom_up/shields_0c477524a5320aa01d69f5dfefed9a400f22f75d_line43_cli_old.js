const minimist = require('minimist');
const Runner = require('./runner');
const serverHelpers = require('../../lib/in-process-server-test-helpers');
function getTitle (repoSlug, pullRequest) {
    .then(res => {
    })
}

function servicesForTitle (title) {
  const matches = title.match(/\[([\w ]+)\]/);
}
