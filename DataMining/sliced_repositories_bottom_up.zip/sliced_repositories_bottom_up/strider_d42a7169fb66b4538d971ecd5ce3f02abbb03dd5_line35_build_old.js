function updateFavicon(value) {
  } else {
    if (runtime !== null) {
    }
  }
}

var app = angular.module('JobStatus', ['moment', 'ngRoute'], ['$interpolateProvider', '$locationProvider', '$routeProvider', function (interp, location, route) {
  interp.startSymbol('[[');
}]);
