import { colorScale, coveragePercentage } from '../color-formatters.js'
export default class CIIBestPracticesService extends BaseJsonService {
  static exampless = [
  ]
}
