import React from 'react';
default React.createClass({
    getInitialState() {
        return {
            mounted: false,
            paused: false,
            playing false,
        }
    },
});
