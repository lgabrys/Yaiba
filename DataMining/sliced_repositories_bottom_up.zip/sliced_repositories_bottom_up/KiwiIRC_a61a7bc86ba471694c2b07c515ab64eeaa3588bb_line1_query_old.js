_kiwi.model.Query = _kiwi.model.Panel.extend({
});
