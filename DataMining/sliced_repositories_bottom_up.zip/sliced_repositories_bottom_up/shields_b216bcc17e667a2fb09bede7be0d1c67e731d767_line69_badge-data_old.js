function makeLabel(defaultLabel, overrides) {
  return overrides.label || defaultLabel;
}
