app.controller('AppCtrl', function ($scope, $window, $log, $rootScope) {
    $scope.showBigArtwork = function (img) {
        if ( img !== null ) {
        } else {
    }
});
