  .extend(base => ({
  }))
  .extend(base => ({
    rules: {
      origin: {
        validate(value, helpers) {
          try {
          } catch (e) {}
        },
      },
    },
  }))
