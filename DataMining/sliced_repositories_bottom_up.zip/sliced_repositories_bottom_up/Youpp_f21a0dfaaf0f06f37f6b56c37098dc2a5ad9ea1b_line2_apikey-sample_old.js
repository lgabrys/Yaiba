module.exports = {
	key: "your-youtube-api-key-here"
};
