
(function($,window,undefined){
  var str_hashchange = 'hashchange',
  $.fn[ str_hashchange ] = function( fn ) {
  };
  $.fn[ str_hashchange ].delay = 50;
})(jQuery,this);
