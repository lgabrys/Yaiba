const otherStates = ['IN_PROGRESS', 'QUEUED', 'PENDING', 'NO_STATUS']
