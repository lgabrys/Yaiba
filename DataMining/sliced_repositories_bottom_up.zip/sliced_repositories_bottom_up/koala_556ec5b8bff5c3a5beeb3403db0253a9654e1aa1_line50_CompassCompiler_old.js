function CompassCompiler(config) {
}
CompassCompiler.prototype.getCompassCmd = function (flag) {
};
CompassCompiler.prototype.compile = function (file, success, fail) {
	var self = this;
};
