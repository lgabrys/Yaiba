const { inferPullRequest } = require('./infer-pull-request');
function getTitle (owner, repo, pullRequest) {
}
function servicesForTitle (title) {
  const blacklist = ['wip'];
}
