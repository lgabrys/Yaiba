function makeLogo(defaultNamedLogo, overrides) {
  const logo = 'logo' in overrides ? '' + overrides.logo : undefined;
}
