var module = module || {};
module.vendor = angular.module('module.vendor', ['ngTagsInput', 'oc.lazyLoad']);
