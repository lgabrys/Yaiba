angular.module('gisto.service.gitHubAPI', [
], function ($provide) {
    $provide.factory('ghAPI', function ($http, gistData, appSettings, requestHandler, $q) {
    });
})
