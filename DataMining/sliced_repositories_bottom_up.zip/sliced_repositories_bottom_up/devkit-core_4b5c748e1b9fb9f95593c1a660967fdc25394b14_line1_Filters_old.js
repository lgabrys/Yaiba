app.filter('trusted', ['$sce', function ($sce) {
}]);
