import { renderVersionBadge } from '../version.js'
export default class Ubuntu extends BaseJsonService {
  async fetch({ packageName, series }) {
        }
    return this._requestJson({
      options: {
        qs: {
        },
      },
    })
  }
