export function errorLogger (filename, isFatal) {
  return function (err, skipReporting) {
  };
}
