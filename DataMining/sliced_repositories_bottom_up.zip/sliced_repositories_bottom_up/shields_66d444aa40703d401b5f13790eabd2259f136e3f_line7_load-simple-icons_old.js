const simpleIcons = require('simple-icons')

function loadSimpleIcons() {
  Object.keys(simpleIcons).forEach(function(key) {
  })
}
