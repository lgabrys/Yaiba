describe('BaseService', function () {
  describe('ScoutCamp integration', function () {
    const expectedRouteRegex = /^\/foo\/([^\/]+?)(|\.svg|\.json)$/
  })
})
